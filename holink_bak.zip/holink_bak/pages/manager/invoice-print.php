<?php
session_start();
//require('fpdf.php');
$is_loggedin = $_SESSION['logged_in'];
//print_r($is_loggedin);exit();
if(!$is_loggedin)
{
	header("location:../../index.html");
}
$link = mysqli_connect("localhost","thetrips_dev","hK5234VmJdB","thetrips_booking_management");
	if(mysqli_connect_error())
	{
		//print_r(mysqli_connect_error()); exit();
		die("There is some error in connecting to database");
	}
	$id = isset($_GET['id'])?$_GET['id']:'';
	
	$query = "SELECT * FROM `invoice` WHERE `invoice_id`=$id";
	$process_query = mysqli_query($link,$query);
	$project = mysqli_fetch_assoc($process_query);
	// echo "<pre>";
	// print_r($project);
	// while($project = mysqli_fetch_assoc($process_query))
	// {
		// echo "<pre>";
		// print_r($project);
	// }
	// exit();
	
function numberTowords($num)
{ 
$ones = array( 
1 => "One", 
2 => "Two", 
3 => "Three", 
4 => "Four", 
5 => "Five", 
6 => "Six", 
7 => "Seven", 
8 => "Eight", 
9 => "Nine", 
10 => "Ten", 
11 => "Eleven", 
12 => "Twelve", 
13 => "Thirteen", 
14 => "Fourteen", 
15 => "fifteen", 
16 => "Sixteen", 
17 => "Seventeen", 
18 => "Eighteen", 
19 => "Nineteen" 
); 
$tens = array( 
1 => "Ten",
2 => "Twenty", 
3 => "Thirty", 
4 => "Forty", 
5 => "Fifty", 
6 => "Sixty", 
7 => "Seventy", 
8 => "Eighty", 
9 => "Ninety" 
); 
$hundreds = array( 
"Hundred", 
"Thousand", 
"Million", 
"Billion", 
"Trillion", 
"Quadrillion" 
); //limit t quadrillion 
$num = number_format($num,2,".",","); 
$num_arr = explode(".",$num); 
$wholenum = $num_arr[0]; 
$decnum = $num_arr[1]; 
$whole_arr = array_reverse(explode(",",$wholenum)); 
krsort($whole_arr); 
$rettxt = ""; 
foreach($whole_arr as $key => $i){ 
if($i < 20){ 
$rettxt .= $ones[$i]; 
}elseif($i < 100){ 
$rettxt .= $tens[substr($i,0,1)]; 
$rettxt .= " ".$ones[substr($i,1,1)]; 
}else{ 
$rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0]; 
// $rettxt .= " ".$tens[substr($i,1,1)]; 
// $rettxt .= " ".$ones[substr($i,2,1)]; 
} 
if($key > 0){ 
$rettxt .= " ".$hundreds[$key]." "; 
} 
} 
if($decnum > 0){ 
$rettxt .= " and "; 
if($decnum < 20){ 
$rettxt .= $ones[$decnum]; 
}elseif($decnum < 100){ 
$rettxt .= $tens[substr($decnum,0,1)]; 
$rettxt .= " ".$ones[substr($decnum,1,1)]; 
} 
} 
return $rettxt; 
} 

extract($_POST);
if(isset($convert))
{
echo "<p align='center' style='color:blue'>".numberTowords("$num")."</p>";
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin Holiday Link | Print Invoice</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="../../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../../bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <link rel="stylesheet" href="../../dist/css/custom-style.css">
    <link rel="apple-touch-icon" sizes="57x57" href="../../dist/img/apple-icon-57x57.png">
  <link rel="apple-touch-icon" sizes="60x60" href="../../dist/img/apple-icon-60x60.png">
  <link rel="apple-touch-icon" sizes="72x72" href="../../dist/img/apple-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="76x76" href="../../dist/img/apple-icon-76x76.png">
  <link rel="apple-touch-icon" sizes="114x114" href="../../dist/img/apple-icon-114x114.png">
  <link rel="apple-touch-icon" sizes="120x120" href="../../dist/img/apple-icon-120x120.png">
  <link rel="apple-touch-icon" sizes="144x144" href="../../dist/img/apple-icon-144x144.png">
  <link rel="apple-touch-icon" sizes="152x152" href="../../dist/img/apple-icon-152x152.png">
  <link rel="apple-touch-icon" sizes="180x180" href="../../dist/img/apple-icon-180x180.png">
  <link rel="icon" type="image/png" sizes="192x192"  href="../../dist/img/android-icon-192x192.png">
  <link rel="icon" type="image/png" sizes="32x32" href="../../dist/img/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="96x96" href="../../dist/img/favicon-96x96.png">
  <link rel="icon" type="image/png" sizes="16x16" href="../../dist/img/favicon-16x16.png">
  <link rel="manifest" href="../../dist/img/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="dist/img/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
  <style type="text/css">
	.invoice_table .table-striped th:last-child,.invoice_table .table-striped td:last-child{
		text-align:right;
	}
	.invoice_table .table>thead>tr>th,.invoice_table .table>tfoot>tr>th{
		border-bottom:2px solid #00c0ef !important;
	}
	.invoice_table .table>tbody>tr>td{
		border-bottom:1px solid #00c0ef !important;
	}
	.top-invoice-dv{text-align:center; min-height:60px;;}
	.top-invoice-dv img{float:left; width:100px;}
	.top-invoice-dv .invoice-id{margin-top:15px; display:inline-block;}
	.top-invoice-dv .due-date{font-size:12px;}
  </style>
</head>
<body onload="window.print();">
<div class="wrapper">
 <!-- Main content -->
    <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header top-invoice-dv">
			
			<span class="invoice-id" style="color:#00c0ef;font-style:italic;font-weight:700; margin-left:20%;"><img class="logo-img" src="../../dist/img/logoimage.png" alt="logo"></span >
			<div class="pull-right">
				<small class="">Date: <?php echo isset($project['createddate'])?$project['createddate']:'';?></small>
				<div class="due-date">Due Date: <?php echo isset($project['createddate'])?$project['createddate']:'';?></div>
				<div class="">Invoice ID: <?php echo $project['invoice_id'];?></div>
			</div>
            
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
	  
	  <?php /* ?>
	  <div class="row">
		<div class="col-sm-4">
			<div class="invoice_div">
				<h2>Holiday Link</h2>
				<div class="address">51, CENTRAL ROAD WWW.HOLIDAYLINK.CO.IN Kolkata, West Bengal (WB - 19), PIN Code 700032, India </div>
				<div class="phone">9831310522</div>
				<div class="mail">HOLIDAYLINK05@GMAIL.COM</div>
				<div class="web">WWW.HOLIDAYLINK.CO.IN</div>
				<div class="tin">GSTIN: 19AXNPS7452G1ZS</div>
			</div><!-- invoice div -->
		</div><!-- col -->
		<div class="col-sm-4">
			<div class="invoice_div">
				<h2>Bill To:</h2>
				<div class="">VIVO COMMUNICATION DEVICE PVT. LTD</div>
				<div class="address"><?php echo isset($project['bill_to'])?$project['bill_to']:''?> </div>				
				<div class="tin">GSTIN: <?php echo !empty($project['customer_gst_no'])?$project['customer_gst_no']:'Not Available'?></div>
			</div><!-- invoice div -->
		</div><!-- col -->
		<div class="col-sm-4">
			<div class="invoice_div">
				<h2>Ship To:</h2>
				<div class="">VIVO COMMUNICATION DEVICE PVT. LTD</div>
				<div class="address"><?php echo isset($project['ship_to'])?$project['ship_to']:''?></div>				
				<div class="user">VIVO COMMUNICATION DEVICE PVT. LTD</div>
			</div><!-- invoice div -->
		</div><!-- col -->
	  </div><!-- row -->
	  <?php */ ?>
	  
	  <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped invoice_div">
            <thead>
            <tr>
              <th><h2>Holiday Link</h2></th>
              <th><h2>Bill To:</h2></th>
              <th><h2>Ship To:</h2></th>
            </tr>
            </thead>
            <tbody>
            <tr>
			  <td>
				<div>
					<div class="address">51, CENTRAL ROAD, Jadavpur, Kolkata, West Bengal (WB - 19), PIN Code 700032, India </div>
					<div class="phone">9831310522</div>
					<div class="mail">HOLIDAYLINK05@GMAIL.COM</div>
					<div class="web">WWW.HOLIDAYLINK.CO.IN</div>
					<div class="tin">GSTIN: 19AXNPS7452G1ZS</div>
				</div>
			  </td>
			  <td>
				<div style="border:1px solid #00c0ef; border-radius:8px;">
					<div class="user"><?php echo isset($project['bill_to_name'])?$project['bill_to_name']:''?></div>
          <div class=""><?php echo isset($project['bill_to_no'])?$project['bill_to_no']:''?></div>
					<div class="address"><?php echo isset($project['bill_to'])?$project['bill_to']:''?> </div>
					<div class="tin">GSTIN: <?php echo !empty($project['customer_gst_no'])?$project['customer_gst_no']:'Not Available'?></div>
				</div>
			  </td>
			  <td>
				<div style="border:1px solid #00c0ef; border-radius:8px;">
					<div class="user"><?php echo isset($project['ship_to_name'])?$project['ship_to_name']:''?></div>
          <div class="user"><?php echo isset($project['ship_to_no'])?$project['ship_to_no']:''?></div>
					<div class="address"><?php echo isset($project['ship_to'])?$project['ship_to']:''?></div>
				</div></br>
				<span style="float:right"> Pay By <?= $project['due_date']; ?>
			  </td>
            </tr>
          </table>
        </div>
        <!-- /.col -->
      </div>
	  
	  <!-- Table row -->
	  <div class="invoice_table">
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
              <th>No</th>
              <th>PRODUCT / SERVICE NAME</th>
              <th>QTY UOM</th>
              <th>UNIT PRICE</th>
              <th>CGST</th>
              <th>SGST</th>
              <th>IGST</th>
              <th>AMOUNT</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <!--<td>1</td>
              <td>COORG TOUR PROGRAM 3 NIGHTS / 4DAYS MEAL PLAN : MAP PICK UP & DROP : BENGALURU AIRPORT INCLUSIONS : CAR, 1 DAYS SIGHT SEEING, FOODING & LODGING. SAC: 00440063</td>
              <td>2.00</td>
              <td>15,2380.00</td>
              <td>761.90</td>
              <td>761.90</td>
              <td>0.00</td>
              <td>31,999.80</td>-->
			  <?php if(isset($project['product_service1'])){
				  ?>
			  <td><?php echo !empty($project['product_service1'])?'1':''?></td>
              <td><?php echo !empty($project['product_service1'])?$project['product_service1']:''?></td>
              <td><?php echo !empty($project['qty1'])?$project['qty1']:''?></td>
              <td><?php echo !empty($project['unit_price1'])?$project['unit_price1']:''?></td>
              <td><?php echo !empty($project['cgst1'])?$project['cgst1']:''?></td>
              <td><?php echo !empty($project['sgst1'])?$project['sgst1']:''?></td>
              <td><?php echo !empty($project['igst1'])?$project['igst1']:''?></td>
              <td><?php echo !empty($project['amount1'])?$project['amount1']:''?></td>
			  <?php } ?>
            </tr>
			 <?php if(isset($project['product_service2'])&&!empty($project['product_service2'])){
				  ?><tr>
			  <!--<td>2</td>
              <td><b>COORG TOUR PROGRAM (CHILD BELOW 10 YEARS)</b> 3 NIGHTS / 4DAYS MEAL PLAN : MAP PICK UP & DROP : BENGALURU AIRPORT INCLUSIONS : CAR, 1 DAYS SIGHT SEEING, FOODING & LODGING. <b>SAC: 00440063</b></td>
              <td>2.00</td>
              <td>76,19.00</td>
              <td>380.95</td>
              <td>380.95</td>
              <td>0.00</td>
              <td>15,999.90</td>-->
			  	 
			  <td><?php echo !empty($project['product_service2'])?'2':''?></td>
              <td><?php echo !empty($project['product_service2'])?$project['product_service2']:''?></td>
              <td><?php echo !empty($project['qty2'])?$project['qty2']:''?></td>
              <td><?php echo !empty($project['unit_price2'])?$project['unit_price2']:''?></td>
              <td><?php echo !empty($project['cgst2'])?$project['cgst2']:''?></td>
              <td><?php echo !empty($project['sgst2'])?$project['sgst2']:''?></td>
              <td><?php echo !empty($project['igst2'])?$project['igst2']:''?></td>
              <td><?php echo !empty($project['amount2'])?$project['amount2']:''?></td>
			
			</tr> <?php } ?>
			 <?php if(isset($project['product_service3'])&&!empty($project['product_service3'])){
				  ?><tr> 
              <!--<td>3</td>
              <td><b>COORG TOUR PROGRAM (CHILD BELOW 10 YEARS)</b> 3 NIGHTS / 4DAYS MEAL PLAN : MAP PICK UP & DROP : BENGALURU AIRPORT INCLUSIONS : CAR, 1 DAYS SIGHT SEEING, FOODING & LODGING. <b>SAC: 00440063</b></td>
              <td>1.00</td>
              <td>0.00</td>
              <td>0.00</td>
              <td>0.00</td>
              <td>0.00</td>
              <td>0.00</td>-->
			 
			  <td><?php echo !empty($project['product_service3'])?'3':''?></td>
              <td><?php echo !empty($project['product_service2'])?$project['product_service3']:''?></td>
              <td><?php echo !empty($project['qty3'])?$project['qty2']:''?></td>
              <td><?php echo !empty($project['unit_price3'])?$project['unit_price3']:''?></td>
              <td><?php echo !empty($project['cgst3'])?$project['cgst3']:''?></td>
              <td><?php echo !empty($project['sgst3'])?$project['sgst3']:''?></td>
              <td><?php echo !empty($project['igst3'])?$project['igst3']:''?></td>
              <td><?php echo !empty($project['amount3'])?$project['amount3']:''?></td>
			  
            </tr>  <?php } ?>          
            </tbody>
			<tfoot>
				<tr>
					<th></th>
					<th>TOTAL</th>
					<th><?php echo !empty($project['qty1'])?$project['qty1']+$project['qty2']+$project['qty3']:''?></th>
					<th></th>
					<th><?php echo !empty($project['cgst2'])?$project['cgst1']+$project['cgst2']+$project['cgst3']:''?></th>
					<th><?php echo !empty($project['sgst1'])?$project['sgst1']+$project['sgst2']+$project['sgst3']:''?></th>
					<th><?php echo !empty($project['igst1'])?$project['igst1']+$project['igst2']+$project['igst3']:''?></th>
						<th><?php echo !empty($project['amount1'])?$project['amount1']+$project['amount2']+$project['amount3']:''?></th>
				</tr>
			</tfoot>
          </table>
        </div>
        <!-- /.col -->
      </div>
	  </div><!-- invoice_table -->
      <!-- /.row -->
	  
	  
	  
	  <div class="invoice_total">
	  <div class="row">
        <!-- accepted payments column -->
        <div class="col-xs-6">
          
           <table class="table" style="font-size:15px; float:left;">
              <tr>
                <td></td>
				<td></td>
              </tr>
              <tr>
                <td></td>
              </tr>
              <tr>
                 <td style="font-size:15px; float:left;><p class="lead">AUTHORIZED SIGNATORY</p></td>
              </tr>
              <tr>
               <td></td>
              </tr>
			  <tr>
               <td></td>
              </tr>
			  <tr>
                <td></td>
              </tr>
			   <tr>
                <td></td>
              </tr>
			   <tr>
                <td></td>
              </tr>
			   <tr>
                <td></td>
              </tr> <tr>
                <td></td>
              </tr>
			  <tr>
				<td style="float:left">Date <?= $project['createddate']?></td>
			  </tr>
			 <tr>
				<td style="float:left">Place Kolkata</td>
			 </tr>
            </table>         
        </div>
        <!-- /.col -->
        <div class="col-xs-6">
          <div class="table-responsive">
            <table class="table" style="font-size:15px">
              <tr>
                <th style="width:50%;">TOTAL BEFORE TAX</th>
                <td><?php echo !empty($project['amount1'])?($project['unit_price1']*$project['qty1'])+($project['unit_price2']*$project['qty2'])+($project['unit_price3']*$project['qty3']):''?></td>
              </tr>
              <tr>
                <th>TOTAL TAX AMOUNT</th>
                <td><?php echo !empty($project['cgst1'])?$project['cgst1']+$project['cgst2']+$project['cgst3']+$project['sgst1']+$project['sgst2']+$project['sgst3']+$project['igst1']+$project['igst2']+$project['igst3']:''?></td>
              </tr>
              <tr>
                 <th>ROUNDED OFF</th><?php $rounded_off = round(($project['amount1']+$project['amount2']+$project['amount3'])-floor($project['amount1']+$project['amount2']+$project['amount3']),2); ?>
                <td><?php echo !empty($project['amount1'])?$rounded_off:'';?></td>
              </tr>
              <tr>
                <th>TOTAL AMOUNT</th>
                <td><?php echo !empty($project['amount1'])?$project['amount1']+$project['amount2']+$project['amount3']-$rounded_off:'';?></td>
              </tr>
			  <tr>
                <th>AMOUNT RECIEVED</th>
                <td>( - )<?php echo !empty($project['amt_received'])?$project['amt_received']:'0';?></td>
              </tr>
			  <tr>
                <th>AMOUNT DUE</th>
                <td><?php echo !empty($project['amount1'])?$project['amount1']+$project['amount2']+$project['amount3']-$project['amt_received']-$rounded_off:'';?></td>
              </tr>
			  <tr><td colspan=2>Rupees <?php echo numberTowords($project['amount1']+$project['amount2']+$project['amount3']-$rounded_off); ?></td></tr>
            </table>
			
          </div>
        </div>
        <!-- /.col -->
      </div>
	  </div><!-- invoice_total -->
      <!-- /.row -->
	  
      <?php /* ?>
	  <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
          From
          <address>
            <strong>Admin, Inc.</strong><br>
            795 Folsom Ave, Suite 600<br>
            San Francisco, CA 94107<br>
            Phone: (804) 123-5432<br>
            Email: info@almasaeedstudio.com
          </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
          To
          <address>
            <strong>John Doe</strong><br>
            795 Folsom Ave, Suite 600<br>
            San Francisco, CA 94107<br>
            Phone: (555) 539-1037<br>
            Email: john.doe@example.com
          </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
          <b>Invoice #007612</b><br>
          <br>
          <b>Order ID:</b> 4F3S8J<br>
          <b>Payment Due:</b> 2/22/2014<br>
          <b>Account:</b> 968-34567
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
	  

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Qty</th>
              <th>Product</th>
              <th>Serial #</th>
              <th>Description</th>
              <th>Subtotal</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>1</td>
              <td>Call of Duty</td>
              <td>455-981-221</td>
              <td>El snort testosterone trophy driving gloves handsome</td>
              <td>$64.50</td>
            </tr>
            <tr>
              <td>1</td>
              <td>Need for Speed IV</td>
              <td>247-925-726</td>
              <td>Wes Anderson umami biodiesel</td>
              <td>$50.00</td>
            </tr>
            <tr>
              <td>1</td>
              <td>Monsters DVD</td>
              <td>735-845-642</td>
              <td>Terry Richardson helvetica tousled street art master</td>
              <td>$10.70</td>
            </tr>
            <tr>
              <td>1</td>
              <td>Grown Ups Blue Ray</td>
              <td>422-568-642</td>
              <td>Tousled lomo letterpress</td>
              <td>$25.99</td>
            </tr>
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
	  

      <div class="row">
        <!-- accepted payments column -->
        <div class="col-xs-6">
          <p class="lead">Payment Methods:</p>
          <img src="../../dist/img/credit/visa.png" alt="Visa">
          <img src="../../dist/img/credit/mastercard.png" alt="Mastercard">
          <img src="../../dist/img/credit/american-express.png" alt="American Express">
          <img src="../../dist/img/credit/paypal2.png" alt="Paypal">

          <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
            Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles, weebly ning heekya handango imeem plugg
            dopplr jibjab, movity jajah plickers sifteo edmodo ifttt zimbra.
          </p>
        </div>
        <!-- /.col -->
        <div class="col-xs-6">
          <p class="lead">Amount Due 2/22/2014</p>

          <div class="table-responsive">
            <table class="table">
              <tr>
                <th style="width:50%">Subtotal:</th>
                <td>$250.30</td>
              </tr>
              <tr>
                <th>Tax (9.3%)</th>
                <td>$10.34</td>
              </tr>
              <tr>
                <th>Shipping:</th>
                <td>$5.80</td>
              </tr>
              <tr>
                <th>Total:</th>
                <td>$265.24</td>
              </tr>
            </table>
          </div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
	  <?php */ ?>

    
    </section>
    <!-- /.content -->
</div>
<!-- ./wrapper -->
</body>
</html>
