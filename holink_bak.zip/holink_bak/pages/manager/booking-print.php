<?php
session_start();
//require('fpdf.php');
$is_loggedin = $_SESSION['logged_in'];
//print_r($is_loggedin);exit();
if(!$is_loggedin)
{
	header("location:../../index.html");
}
$link = mysqli_connect("localhost","thetrips_dev","hK5234VmJdB","thetrips_booking_management");
	if(mysqli_connect_error())
	{
		//print_r(mysqli_connect_error()); exit();
		die("There is some error in connecting to database");
	}
	$id = isset($_GET['id'])?$_GET['id']:'';
	
	$query = "SELECT * FROM `booking_form` WHERE `booking_id`=$id";
	$process_query = mysqli_query($link,$query);
	$project = mysqli_fetch_assoc($process_query);
	// echo "<pre>";
	// print_r($project);
	// while($project = mysqli_fetch_assoc($process_query))
	// {
		// echo "<pre>";
		// print_r($project);
	// }
	// exit();
	
function numberTowords($num){
$ones = array( 
1 => "One", 
2 => "Two", 
3 => "Three", 
4 => "Four", 
5 => "Five", 
6 => "Six", 
7 => "Seven", 
8 => "Eight", 
9 => "Nine", 
10 => "Ten", 
11 => "Eleven", 
12 => "Twelve", 
13 => "Thirteen", 
14 => "Fourteen", 
15 => "fifteen", 
16 => "Sixteen", 
17 => "Seventeen", 
18 => "Eighteen", 
19 => "Nineteen" 
); 
$tens = array( 
1 => "Ten",
2 => "Twenty", 
3 => "Thirty", 
4 => "Forty", 
5 => "Fifty", 
6 => "Sixty", 
7 => "Seventy", 
8 => "Eighty", 
9 => "Ninety" 
); 
$hundreds = array( 
"Hundred", 
"Thousand", 
"Million", 
"Billion", 
"Trillion", 
"Quadrillion" 
); //limit t quadrillion 
$num = number_format($num,2,".",","); 
$num_arr = explode(".",$num); 
$wholenum = $num_arr[0]; 
$decnum = $num_arr[1]; 
$whole_arr = array_reverse(explode(",",$wholenum)); 
krsort($whole_arr); 
$rettxt = ""; 
foreach($whole_arr as $key => $i){ 
if($i < 20){ 
$rettxt .= $ones[$i]; 
}elseif($i < 100){ 
$rettxt .= $tens[substr($i,0,1)]; 
$rettxt .= " ".$ones[substr($i,1,1)]; 
}else{ 
$rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0]; 
// $rettxt .= " ".$tens[substr($i,1,1)]; 
// $rettxt .= " ".$ones[substr($i,2,1)]; 
} 
if($key > 0){ 
$rettxt .= " ".$hundreds[$key]." "; 
} 
} 
if($decnum > 0){ 
$rettxt .= " and "; 
if($decnum < 20){ 
$rettxt .= $ones[$decnum]; 
}elseif($decnum < 100){ 
$rettxt .= $tens[substr($decnum,0,1)]; 
$rettxt .= " ".$ones[substr($decnum,1,1)]; 
} 
} 
return $rettxt; 
} 

extract($_POST);
if(isset($convert))
{
echo "<p align='center' style='color:blue'>".numberTowords("$num")."</p>";
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin Holiday Link | Print Invoice</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="../../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../../bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <link rel="stylesheet" href="../../dist/css/custom-style.css">
    <link rel="apple-touch-icon" sizes="57x57" href="../../dist/img/apple-icon-57x57.png">
  <link rel="apple-touch-icon" sizes="60x60" href="../../dist/img/apple-icon-60x60.png">
  <link rel="apple-touch-icon" sizes="72x72" href="../../dist/img/apple-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="76x76" href="../../dist/img/apple-icon-76x76.png">
  <link rel="apple-touch-icon" sizes="114x114" href="../../dist/img/apple-icon-114x114.png">
  <link rel="apple-touch-icon" sizes="120x120" href="../../dist/img/apple-icon-120x120.png">
  <link rel="apple-touch-icon" sizes="144x144" href="../../dist/img/apple-icon-144x144.png">
  <link rel="apple-touch-icon" sizes="152x152" href="../../dist/img/apple-icon-152x152.png">
  <link rel="apple-touch-icon" sizes="180x180" href="../../dist/img/apple-icon-180x180.png">
  <link rel="icon" type="image/png" sizes="192x192"  href="../../dist/img/android-icon-192x192.png">
  <link rel="icon" type="image/png" sizes="32x32" href="../../dist/img/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="96x96" href="../../dist/img/favicon-96x96.png">
  <link rel="icon" type="image/png" sizes="16x16" href="../../dist/img/favicon-16x16.png">
  <link rel="manifest" href="../../dist/img/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="dist/img/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
  
  <style type="text/css">
	.page-header{margin-bottom:0;}
	.tour-table-bx{margin:0 !important;}
	@media print {
      body, html, .tour-table-bx {
          width: 100%;
      }
    /*div { page-break-inside:auto }*/
    /*div    { page-break-inside:avoid; page-break-after:auto }*/
    div { display:table-header-group; width: 100%; }
    /*div { display:table-footer-group }*/
}
  </style>
  
</head>
<body onload="window.print();">
<div class="wrapper">
<!-- Main content -->
    <section class="tour-table-bx">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header text-center">
			<img class="logo-img" src="../../dist/img/logoimage.png" alt="logo">
          </h2>
		  <h2 class="page-header text-center">
			<?php echo isset($project['tour_head'])?$project['tour_head']:'Not Available'; ?>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
	  
	  <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">            
            <tbody>
                 <tr>
					<th>Client Name: </th>
					<td><?php echo isset($project['name'])?$project['name']:''; ?></td>
					<th>Mobile:</th>
					<td><?php echo isset($project['mobile'])?$project['mobile']:''; ?></td>
				 </tr>
				 <tr>
					<th>Tour Head:  </th>
					<td><?php echo isset($project['tour_head'])?$project['tour_head']:''; ?></td>
					<th>PAX: </th>
					<td><?php echo isset($project['pax'])?$project['pax']:''; ?></td>
				 </tr>
				 <tr>
					<th>Duration</th>
					<td><?php echo isset($project['duration'])?$project['duration']:''; ?></td>
					<th>Booking ID</th>
					<td>#<?php echo isset($project['booking_id'])?$project['booking_id']:''; ?></td>
				 </tr>
				 <tr>
					<th>Car Type </th>
					<td><?php echo isset($project['car_type'])?$project['car_type']:''; ?></td>
					<th>Ticket: </th>
					<td><?php echo isset($project['ticket_requirements'])?$project['ticket_requirements']:''; ?></td>
				 </tr>
				 <tr>
					<th>VISA:</th>
					<td><?php echo isset($project['visa_requirements'])?$project['visa_requirements']:''; ?></td>
					<th>MEAL Plan</th>
					<td><?php echo isset($project['meal_plan'])?$project['meal_plan']:''; ?></td>
				 </tr>
            </tbody>			
          </table>
        </div>
        <!-- /.col -->
      </div>
	  
	  <div class="row">
        <div class="col-xs-12 table-responsive text-center">
          <table class="table table-striped">            
            <tbody>
                 <tr>
					<th colspan="4"><div class="text-center">Hotel Details </div></th>					
				 </tr>
				 <tr>
					<td><b>Hotel Name </b></td>
					<td><b>Room Type </b></td>
					<td><b>Check In Date </b></td>
					<td><b>Check Out Date </b></td>
				 </tr>
				 <tr>
					<td><?php echo isset($project['hotel1'])?$project['hotel1']:''; ?></td>
					<td><?php echo isset($project['room_type1'])?$project['room_type1']:''; ?></td>
					<td><?php echo isset($project['checkin_date1']) && ($project['checkin_date1'] != '0000-00-00')?$project['checkin_date1']:''; ?></td>
					<td><?php echo isset($project['checkout_date1'])&& ($project['checkout_date1'] != '0000-00-00')?$project['checkout_date1']:''; ?></td>
				 </tr>
				 <tr>
				<td><?php echo isset($project['hotel2'])?$project['hotel2']:''; ?></td>
          <td><?php echo isset($project['room_type2'])?$project['room_type2']:''; ?></td>
          <td><?php echo isset($project['checkin_date2'])&& ($project['checkin_date2'] != '0000-00-00')?$project['checkin_date2']:''; ?></td>
          <td><?php echo isset($project['checkout_date2'])&& ($project['checkout_date2'] != '0000-00-00')?$project['checkout_date2']:''; ?></td>
				 </tr>
				 <tr>
					<td><?php echo isset($project['hotel3'])?$project['hotel3']:''; ?></td>
          <td><?php echo isset($project['room_type3'])?$project['room_type3']:''; ?></td>
          <td><?php echo isset($project['checkin_date3'])&& ($project['checkin_date3'] != '0000-00-00')?$project['checkin_date3']:''; ?></td>
          <td><?php echo isset($project['checkout_date3'])&& ($project['checkout_date3'] != '0000-00-00')?$project['checkout_date3']:''; ?></td>
				 </tr>
            </tbody>			
          </table>
        </div>
        <!-- /.col -->
      </div>
		  
	  <div class="row">
		<div class="col-md-12" style="margin-bottom:6px;">
			<div class="text-box">
				   <?php 
              $string = $project['itinerary1'];
              $string = explode("*",$string);
        if(!empty($string)){
              foreach ($string as $key => $str) {
                $day = $key;
                if(!empty($str)){
          echo '<b>Day</b>  '.$day .'</br>'.$str.'</br>'.'</br>';}
              } }         
            ?>    
			</div>
		</div>
		
	  </div>
	  	  	  
	  <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">            
            <tbody>
                 <tr>
					<th>Inclusion</th>
					<th>Exclusions </th>
				 </tr>
				 <tr>
					<td>
						<ul>
			<?php  
              $string = $project['inclusions'];
              $string = explode(",",$string);
             if(!empty($string)){
              foreach ($string as $str) {
				  if(!empty($str)){
				  echo "<li>".$str."</li>";}
              }	}         
            ?>			
						</ul>
					</td>
					<td>
						<ul>
			<?php  
              $string = $project['exclusions'];
              $string = explode(",",$string);
             if(!empty($string)){
              foreach ($string as $str) {
				  if(!empty($str)){
				  echo "<li>".$str."</li>";}
              }	}         
            ?>				
							<?/*li>LoremIpsumissimplydummytext.</li>							
							<li>LoremIpsumissimplydummytext.</li>							
							<li>LoremIpsumissimplydummytext.</li */?>							
						</ul>
					</td>
				 </tr>				 
            </tbody>			
          </table>
        </div>
        <!-- /.col -->
      </div>
	  
	  <div class="row">
		<div class="col-md-12">
			<div class="text-box">
				<h3>Terms & Conditions:</h3>
				<ul>
			<?php  
              $string = $project['tnc'];
              $string = explode(",",$string);
             if(!empty($string)){
              foreach ($string as $str) {
				  if(!empty($str)){
				  echo "<li>".$str."</li>";}
              }	}         
            ?>			
				</ul>
			</div>
		</div>		
	  </div>
    </section>
    <!-- /.content -->
</div>
<!-- ./wrapper -->
</body>
</html>