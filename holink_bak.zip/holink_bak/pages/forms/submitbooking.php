<?php

$link = mysqli_connect("localhost","thetrips_dev","hK5234VmJdB","thetrips_booking_management");
	if(mysqli_connect_error())
	{
		//print_r(mysqli_connect_error()); exit();
		die("There is some error in connecting to database");
	}
	
	$name = $_POST['name'];
	$mobile = $_POST['mobile'];
	$email = $_POST['email'];
	$duration = $_POST['dur_day'].' & '.$_POST['dur_night'];
	$address = $_POST['address'];
	$shipto = $_POST['address'];
	$invoice_id = $_POST['invoice_id'];
	$tour_type = $_POST['tour_type'];
	$tour_head = $_POST['tour_head'];
	$pax = $_POST['pax'];
	$tnc = $_POST['tnc'];
	
	// $itinerary = $_POST['itinerary'];
	$meal_plan = $_POST['meal_plan'];
	$car_type = $_POST['car_type'];
	$car_detail = $_POST['car_details'];
	$ticket_requirement = $_POST['ticket_requirements'];
	$visa_requirement = $_POST['visa_requirements'];
	$inclusions = $_POST['inclusions'];
	$exclusions = $_POST['exclusions'];
	// if(!empty($_POST['itinerary_date'])){
	// foreach($_POST['itinerary_date'] as $key=>$value){
	// 	$itinerary_date[$key] = $value;
	// }
	// }
	// else{
	// 	$itinerary_date[0] = 0;
	// 	$itinerary_date[1] = 0;
	// 	$itinerary_date[2] = 0;
	// }
	
	$itinerary = '';
	foreach($_POST['itinerary'] as $key=>$value){
		$itinerary = $itinerary.'*'.$value;
	}
	foreach($_POST['hotel_name'] as $key=>$value){
		$hotel_name[$key] = $value;
	}
	foreach($_POST['room_type'] as $key=>$value){
		$room_type[$key] = $value;
	}
	foreach($_POST['check_in'] as $key=>$value){
		$check_in[$key] = $value;
	}
	foreach($_POST['check_out'] as $key=>$value )
	{
		$check_out[$key] = $value;
	}
	
	foreach($_POST['reminder_date'] as $key=>$value){
		$reminder_date[$key] = $value;
		// print_r($reminder_date[$key]);
		// exit();
	}
	foreach($_POST['reminder_time'] as $key=>$value){
		$reminder_time[$key] = $value;
	}
	foreach($_POST['reminder_subject'] as $key=>$value){
		$reminder_subject[$key] = $value;
	}

	$date = date('m/d/y');
	// echo "<pre>";
	// print_r("test");
	// exit();
	
	$query = "INSERT INTO `booking_form`(`name`,`email`,`mobile`,`address`,`invoice_id`,`tour_type`,
	`hotel1`,`checkin_date1`,`checkout_date1`,`itinerary1`,`reminder_date1`,
	`reminder_date2`,`reminder_date3`,`checkin_date2`,`checkin_date3`,`checkout_date2`,`checkout_date3`,`meal_plan`,
	`car_type`,`car_details`,`ticket_requirements`,`visa_requirements`,`inclusions`,`exclusions`,`room_type1`,`room_type2`,`room_type3`, `tour_head`,`duration`,`pax`,`hotel2`,`hotel3`,`tnc`,`reminder_subject1`,`reminder_subject2`,`reminder_subject3`,`reminder_time1`,`reminder_time2`,`reminder_time3`) VALUES('$name','$email','$mobile','$address','$invoice_id','$tour_type',
	'$hotel_name[0]','$check_in[0]','$check_out[0]','$itinerary','$reminder_date[0]',
	'$reminder_date[1]','$reminder_date[2]','$check_in[1]','$check_in[2]','$check_out[1]','$check_out[2]','$meal_plan',
	'$car_type','$car_detail','$ticket_requirement','$visa_requirement','$inclusions','$exclusions','$room_type[0]','$room_type[1]','$room_type[2]','$tour_head','$duration','$pax','$hotel_name[1]','$hotel_name[2]','$tnc','$reminder_subject[0]','$reminder_subject[1]','$reminder_subject[2]','$reminder_time[0]','$reminder_time[1]','$reminder_time[2]')";
	// $query = "INSERT INTO `booking_form`(`name`,`email`,`mobile`,`address`,`invoice_id`,`tour_type`,
	// `hotel1`,`checkin_date1`,`checkout_date1`,`itinerary_day1`,`reminder_date1`,`meal_plan`,
	// `car_type`,`car_details`,`ticket_requirements`,`visa_requirements`,`inclusions`,`exclusions`) VALUES('$name','$email','$mobile','$address','$invoice_id','$tour_type',
	// '$hotel_name[0]','$check_in[0]','$check_out[0]','$itinerary_date[0]','$reminder_date[0]','$meal_plan',
	// '$car_type','$car_detail','$ticket_requirement','$visa_requirement','$inclusions','$exclusions')";
	// echo "<pre>";
	// print_r($query);
	// exit();
	$process_query = mysqli_query($link,$query);
	// $result = mysqli_fetch_array($process_query);
	

	header("location:../../generatepdf.php");
	mysqli_close($link);
	
	?>