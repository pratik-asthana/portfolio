<?php 
$recipient = $_POST['recipient'];
$message = $_POST['message'];
$message = urlencode($message);
$recipient = urlencode($recipient);
$url = "http://198.15.103.106/API/pushsms.aspx?loginID=BSAHA&password=123456&mobile=".$recipient."&text=".$message."&senderid=HOLINK&route_id=1&Unicode=0";

$response = file_get_contents($url);
$decode = json_decode($response);
$status = $decode->LoginStatus;
// echo '<pre>';
// print_r($status);
// exit();
$flag = 0;
if($status == 'Success'){
    $flag = 1;
}
header("location:sms.php");
?>