<?php

$link = mysqli_connect("localhost","thetrips_dev","hK5234VmJdB","thetrips_booking_management");
	if(mysqli_connect_error())
	{
		//print_r(mysqli_connect_error()); exit();
		die("There is some error in connecting to database");
	}
	$agencyaddr = $_POST['agencyaddr'];
	$billto = $_POST['billto'];
	$shipto = $_POST['shipto'];
	$billtoname = $_POST['billtoname'];
	$shiptoname = $_POST['shiptoname'];
	$billtono = $_POST['billtono'];
	$shiptono = $_POST['shiptono'];
	$customer_gst_no = $_POST['customer_gst_no'];
	foreach($_POST['service'] as $key=>$value){
		$service[$key] = $value;
	}
	foreach($_POST['qty'] as $key=>$value){
		$qty[$key] = $value;
	}
	foreach($_POST['unit_price'] as $key=>$value){
		$unit_price[$key] = $value;
	}
	foreach($_POST['gst'] as $key=>$value )
	{
		$gst[$key] = $value;
	}
	if($gst[0]==0)
	{
		$cgst[0] = 0;
		$sgst[0] = 0;
 	}
	else{
		$cgst[0] = round((2.5/100)*$unit_price[0],2);
		$sgst[0] = round((2.5/100)*$unit_price[0],2);
	}
	if($gst[1]==0)
	{
		$cgst[1] = 0;
		$sgst[1] = 0;
 	}
	else{
		$cgst[1] = round((2.5/100)*$unit_price[1],2);
		$sgst[1] = round((2.5/100)*$unit_price[1],2);
	}
	if($gst[2]==0)
	{
		$cgst[2] = 0;
		$sgst[2] = 0;
 	}
	else{
		$cgst[2] = round((2.5/100)*$unit_price[2],2);
		$sgst[2] = round((2.5/100)*$unit_price[2],2);
	}
	// foreach($_POST['cgst'] as $key=>$value){
	// 	$cgst[$key] = $value;
	// }
	// foreach($_POST['sgst'] as $key=>$value){
	// 	$sgst[$key] = $value;
	// }
	foreach($_POST['igst'] as $key=>$value){
		$igst[$key] = $value;
	}
	// foreach($_POST['amount'] as $key=>$value){
		// $amount[$key] = $value;
	// }
	$qty[0] = (int)$qty[0];
	$qty[1] = (int)$qty[1];
	$qty[2] = (int)$qty[2];
	$unit_price[0] = (float)$unit_price[0];
	$unit_price[1] = (float)$unit_price[1];
	$unit_price[2] = (float)$unit_price[2];
	$sgst[0] = (float)$sgst[0];
	$sgst[1] = (float)$sgst[1];		
	$sgst[2] = (float)$sgst[2];
	$cgst[0] = (float)$cgst[0];
	$cgst[1] = (float)$cgst[1];
	$cgst[2] = (float)$cgst[2];
	$igst[0] = (float)$igst[0];
	$igst[1] = (float)$igst[1];
	$igst[2] = (float)$igst[2];
	$amount[0] = ($qty[0]*$unit_price[0])+$sgst[0]+$cgst[0]+$igst[0];
	$amount[1] = ($qty[1]*$unit_price[1])+$sgst[1]+$cgst[1]+$igst[1];
	$amount[2] = ($qty[2]*$unit_price[2])+$sgst[2]+$cgst[2]+$igst[2];
	$amt_received = $_POST['amt_received'];
	$due_date = $_POST['due_date'];
	$date = date('m/d/y');
	// echo "<pre>";
	// print_r("test");
	// exit();
	// $query = "INSERT INTO `invoice`(`agency_address`,`bill_to`,`ship_to`) VALUES('$agencyaddr','$billto','$shipto')";
	$query = "INSERT INTO `invoice`(`agency_address`,`bill_to`,`ship_to`,`customer_gst_no`,`product_service1`,`qty1`,
	`unit_price1`,`cgst1`,`sgst1`,`igst1`,`amount1`,`product_service2`,`qty2`,
	`unit_price2`,`cgst2`,`sgst2`,`igst2`,`amount2`,`product_service3`,`qty3`,
	`unit_price3`,`cgst3`,`sgst3`,`igst3`,`amount3`,`amt_received`,`createddate`,`bill_to_name`,`ship_to_name`,`bill_to_no`,`ship_to_no`,`due_date`) VALUES('$agencyaddr','$billto','$shipto','$customer_gst_no','$service[0]','$qty[0]',
	'$unit_price[0]','$cgst[0]','$sgst[0]','$igst[0]','$amount[0]','$service[1]','$qty[1]',
	'$unit_price[1]','$cgst[1]','$sgst[1]','$igst[1]','$amount[1]','$service[2]','$qty[2]',
	'$unit_price[2]','$cgst[2]','$sgst[2]','$igst[2]','$amount[2]','$amt_received','$date','$billtoname','$shiptoname','$billtono','$shiptono','$due_date')";
	// echo "<pre>";
	// print_r($query);
	// exit();
	$process_query = mysqli_query($link,$query);
	// $result = mysqli_fetch_array($process_query);
	

	header("location:thanks.php");
	mysqli_close($link);
	
	?>