<!DOCTYPE html>
<html>
<head>
	<title>Invoice has been generated</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="apple-touch-icon" sizes="57x57" href="../../dist/img/apple-icon-57x57.png">
  <link rel="apple-touch-icon" sizes="60x60" href="../../dist/img/apple-icon-60x60.png">
  <link rel="apple-touch-icon" sizes="72x72" href="../../dist/img/apple-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="76x76" href="../../dist/img/apple-icon-76x76.png">
  <link rel="apple-touch-icon" sizes="114x114" href="../../dist/img/apple-icon-114x114.png">
  <link rel="apple-touch-icon" sizes="120x120" href="../../dist/img/apple-icon-120x120.png">
  <link rel="apple-touch-icon" sizes="144x144" href="../../dist/img/apple-icon-144x144.png">
  <link rel="apple-touch-icon" sizes="152x152" href="../../dist/img/apple-icon-152x152.png">
  <link rel="apple-touch-icon" sizes="180x180" href="../../dist/img/apple-icon-180x180.png">
  <link rel="icon" type="image/png" sizes="192x192"  href="../../dist/img/android-icon-192x192.png">
  <link rel="icon" type="image/png" sizes="32x32" href="../../dist/img/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="96x96" href="../../dist/img/favicon-96x96.png">
  <link rel="icon" type="image/png" sizes="16x16" href="../../dist/img/favicon-16x16.png">
  <link rel="manifest" href="../../dist/img/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="dist/img/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
</head>
<body>
<div class="jumbotron text-xs-center">
  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong>The invoice has been generated.</strong></p>
  <hr>
 
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="../../dashboard.php" role="button">Continue to Dashboard</a>
  </p>
</div>
<script>
window.setTimeout(function() {
location.href = "invoice.php";
}, 3300);
</script>
</body>
</html>
<?php
   // $now = time();
    // while ($now + 3 > time()) {
       // echo time(); 
    // }		
// header("location:invoice.php");
?>