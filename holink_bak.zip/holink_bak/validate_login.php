<?php
session_start();
$_SESSION['logged_in'] = false;
$link = mysqli_connect("localhost","thetrips_dev","hK5234VmJdB","thetrips_booking_management");
	if(mysqli_connect_error())
	{
		//print_r(mysqli_connect_error()); exit();
		die("There is some error in connecting to database");
	}
	$username = $_POST['username'];
	$password = $_POST['password'];
	$hashed_password = md5($password);
	$query = "Select `username`,`password` from `user` WHERE `username` = '$username' AND `password` = '$hashed_password'"; 
	$process_query = mysqli_query($link,$query);
	$result = mysqli_fetch_array($process_query);
	//print_r($result);exit();
	if(!empty($result)){
	$_SESSION['logged_in'] = true; //set you've logged in
	$_SESSION['last_activity'] = time(); //your last activity was now, having logged in.
	//$_SESSION['expire_time'] = 3*60*60;
	//print_r($_SESSION['logged_in']);exit();
	}
	if($_SESSION['logged_in']==true)
	{
		header("location:dashboard.php");
	}
	else{
	header("location:index.html");
	}
	mysqli_close($link);
	
	?>