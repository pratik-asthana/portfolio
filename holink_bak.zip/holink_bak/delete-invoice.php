<?php

$link = mysqli_connect("localhost","thetrips_dev","hK5234VmJdB","thetrips_booking_management");
	if(mysqli_connect_error())
	{
		//print_r(mysqli_connect_error()); exit();
		die("There is some error in connecting to database");
	}
	$id = $_GET['id'];
	$query = "DELETE FROM `invoice` WHERE `invoice_id` = '$id'";
	$process_query = mysqli_query($link,$query);
	// while($project = mysqli_fetch_assoc($process_query))
	// {
		// echo "<pre>";
		// echo $project['invoice_id'];
	// }
	
	// print_r($projects);
	// foreach($result as $key=>$value)
	// {
		// echo $value;
	// }
	// exit();
		header("location:pages/tables/invoice-list.php");
mysqli_close($link);
	
?>