<?php
// session_start();
// $_SESSION['logged_in'] = true; //set you've logged in
// $_SESSION['last_activity'] = time(); //your last activity was now, having logged in.
// $name = $_POST['name'];
// $mobile = $_POST['mobile'];
// $address = $_POST['address'];
// $invoice_id = $_POST['invoice_id'];
// $tour_type = $_POST['tour_type'];
// $tour = $_POST['tour'];
// $itinerary = $_POST['itinerary'];
// $meal_plan = $_POST['meal_plan'];
// $car_type = $_POST['car_type'];
// $car_details = $_POST['car_details'];
// $ticket_requirements = $_POST['ticket_requirements'];
// $visa_requirements = $_POST['visa_requirements'];
// $inclusions = $_POST['inclusions'];
// $exclusions = $_POST['exclusions'];
// $hotel_count = sizeof($_POST['hotel_name']);

// require('fpdf.php');
		// $pdf = new FPDF('P','mm','A3');
		// $pdf->AddPage();
		// $pdf->SetFont('Arial','B',12.4);
		// $pdf->Multicell(179,20,"",0,"C");
		// $pdf->SetFont('Arial','B',15);
		// $pdf->SetTextColor(0,149,218);
		// $pdf->SetLineWidth(0.7);
		// $pdf->Multicell(184,20,'Booking Form:',1,"C");
		// $pdf->Multicell(175,10,"",0,"C");
		// $y = $pdf->GetY();
		// $pdf->SetFont('Arial','B',11);
		// $pdf->SetTextColor(52,60,63);
		// $pdf->SetLineWidth(0);
		// $pdf->Multicell(74,12,'Name: ',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y);
		// $pdf->Multicell(110,12,$name,1,"L");
		// $pdf->Multicell(74,12,'Mobile: ',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+12);
		// $pdf->Multicell(110,12,$mobile,1,"L");
		// $pdf->Multicell(74,12,'Address:',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+24);
		// $pdf->Multicell(110,12,$address,1,"L");
		// $pdf->Multicell(74,12,'Invoice ID: ',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+36);
		// $pdf->Multicell(110,12,$invoice_id,1,"L");
		// $pdf->Multicell(74,12,'Tour Type: ',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+48);
		// $pdf->Multicell(110,12,$tour_type,1,"L");
		// $pdf->Multicell(74,12,'Itinerary: ' ,1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+60);
		// $pdf->Multicell(110,12,$itinerary,1,"L");
		// $pdf->Multicell(74,12,'Meal Plan:',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+72);
		// $pdf->Multicell(110,12,$meal_plan,1,"L");
		// $pdf->Multicell(74,12,'Car Type:',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+84);
		// $pdf->Multicell(110,12,$car_type,1,"L");
		// $pdf->Multicell(74,12,'Car Details: ',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+96);
		// $pdf->Multicell(110,12, $car_details,1,"L");
		// $pdf->Multicell(74,12,'Ticket Requirements: ',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+108);
		// $pdf->Multicell(110,12,$ticket_requirements,1,"L");
		// $pdf->Multicell(74,12,'Visa Requirements: ',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+120);
		// $pdf->Multicell(110,12,$visa_requirements,1,"L");
		// $pdf->Multicell(74,12,'Inclusions: ',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+132);
		// $pdf->Multicell(110,12,$inclusions,1,"L");
		// $pdf->Multicell(74,12,'Exclusions: ',1,"L");
		// $x = $pdf->GetX();
		// $pdf->SetXY($x + 74, $y+144);
		// $pdf->Multicell(110,12,$exclusions,1,"L");
		// if(!empty($_POST['hotel_name'])){
		// foreach($_POST['hotel_name'] as $key=>$hotel_name)
		// { 
			// $pdf->Multicell(74,12,'Hotel: '.($key+1),1,"L");
			// $x = $pdf->GetX();
			// $pdf->SetXY($x + 74, $y+144+12*($key+1));
			// $pdf->Multicell(110,12,$hotel_name,1,"L");
		// }
		// foreach($_POST['check_in'] as $key=>$check_in)
		// { 
			// $pdf->Multicell(74,12,'Check-in date for Hotel: '.($key+1),1,"L");
			// $x = $pdf->GetX();
			// $pdf->SetXY($x + 74, $y+144+12*$hotel_count+12*($key+1));
			// $pdf->Multicell(110,12,$check_in,1,"L");
		// }
		// foreach($_POST['check_out'] as $key=>$check_out)
		// { 
			// $pdf->Multicell(74,12,'Check-out date for Hotel: '.($key+1),1,"L");
			// $x = $pdf->GetX();
			// $pdf->SetXY($x + 74, $y+144+12*$hotel_count*$hotel_count+12*($key+1));
			// $pdf->Multicell(110,12,$check_out,1,"L");
		// }
		// }
		// if(!empty($_POST['reminder_date'])){
		// foreach($_POST['reminder_date'] as $key=>$reminder_date)
		// { 
			// $pdf->Multicell(74,12,'Reminder date: '.($key+1),1,"L");
			// $x = $pdf->GetX();
			// $pdf->SetXY($x + 74, $y+144+12*$hotel_count*$hotel_count*$hotel_count+12*($key+1));
			// $pdf->Multicell(110,12,$reminder_date,1,"L");
		// }}
        // $filename = $invoice_id.time().'.pdf';
		// $path = dirname(__FILE__);
		// $path1 = $path.'/pages/'.'forms/'.'BookedForms/'.$filename;
		// $pdf->Output($path1,'F');
		// $pdf->Output($filename, 'D');
		
		// $pdf->Output($filename,'I');
		header('location:pages/forms/booking.php');
?>