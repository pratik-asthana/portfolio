-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 05, 2018 at 08:31 AM
-- Server version: 5.7.22-22
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thetrips_booking_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_form`
--

CREATE TABLE `booking_form` (
  `booking_id` int(8) NOT NULL,
  `name` text NOT NULL,
  `mobile` text NOT NULL,
  `tour_head` text NOT NULL,
  `pax` text NOT NULL,
  `duration` text NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `invoice_id` text NOT NULL,
  `tour_type` text NOT NULL,
  `hotel1` text NOT NULL,
  `checkin_date1` date NOT NULL,
  `checkout_date1` date NOT NULL,
  `itinerary1` text NOT NULL,
  `itinerary2` text NOT NULL,
  `itinerary3` text NOT NULL,
  `itinerary_day1` date NOT NULL,
  `itinerary_day2` date NOT NULL,
  `itinerary_day3` date NOT NULL,
  `reminder_date2` date NOT NULL,
  `reminder_date3` date NOT NULL,
  `checkin_date2` date NOT NULL,
  `checkin_date3` date NOT NULL,
  `checkout_date2` date NOT NULL,
  `checkout_date3` date NOT NULL,
  `hotel2` text NOT NULL,
  `hotel3` text NOT NULL,
  `room_type1` varchar(25) NOT NULL,
  `room_type2` varchar(25) NOT NULL,
  `room_type3` varchar(25) NOT NULL,
  `meal_plan` text NOT NULL,
  `car_type` text NOT NULL,
  `car_details` text NOT NULL,
  `ticket_requirements` text NOT NULL,
  `visa_requirements` text NOT NULL,
  `inclusions` text NOT NULL,
  `exclusions` text NOT NULL,
  `reminder_date1` date NOT NULL,
  `checkin_time1` varchar(11) NOT NULL,
  `checkin_time2` varchar(11) NOT NULL,
  `checkin_time3` varchar(11) NOT NULL,
  `checkout_time1` varchar(11) NOT NULL,
  `checkout_time2` varchar(11) NOT NULL,
  `checkout_time3` varchar(11) NOT NULL,
  `reminder_time1` varchar(11) NOT NULL,
  `reminder_time2` varchar(11) NOT NULL,
  `reminder_time3` varchar(11) NOT NULL,
  `Itinerary_time1` varchar(11) NOT NULL,
  `Itinerary_time2` varchar(11) NOT NULL,
  `Itinerary_time3` varchar(11) NOT NULL,
  `reminder_subject1` text NOT NULL,
  `reminder_subject2` text NOT NULL,
  `reminder_subject3` text NOT NULL,
  `tnc` text NOT NULL,
  `createddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking_form`
--

INSERT INTO `booking_form` (`booking_id`, `name`, `mobile`, `tour_head`, `pax`, `duration`, `email`, `address`, `invoice_id`, `tour_type`, `hotel1`, `checkin_date1`, `checkout_date1`, `itinerary1`, `itinerary2`, `itinerary3`, `itinerary_day1`, `itinerary_day2`, `itinerary_day3`, `reminder_date2`, `reminder_date3`, `checkin_date2`, `checkin_date3`, `checkout_date2`, `checkout_date3`, `hotel2`, `hotel3`, `room_type1`, `room_type2`, `room_type3`, `meal_plan`, `car_type`, `car_details`, `ticket_requirements`, `visa_requirements`, `inclusions`, `exclusions`, `reminder_date1`, `checkin_time1`, `checkin_time2`, `checkin_time3`, `checkout_time1`, `checkout_time2`, `checkout_time3`, `reminder_time1`, `reminder_time2`, `reminder_time3`, `Itinerary_time1`, `Itinerary_time2`, `Itinerary_time3`, `reminder_subject1`, `reminder_subject2`, `reminder_subject3`, `tnc`, `createddate`, `user_id`) VALUES
(2, 'Prateek Dev', '7895632912', '1', '0', '1 Day and 1 Night', 'dev.prateek.asthana@gmail.com\r\n', 'Test', 'Test', 'Test', 'The Leela', '2018-11-20', '2018-11-22', 'Some Plan for Today', 'Some Plan for Tomorrow', '', '0000-00-00', '0000-00-00', '0000-00-00', '2018-11-21', '2018-11-22', '2018-11-14', '2018-11-22', '2018-11-22', '2018-11-21', 'Ramada', 'Lemon Tree', 'Non AC', '', '', 'AP', 'Test', 'None', 'None', 'None', 'Test1,Test2, Test3', 'Test4, Test5, Test6', '2018-11-20', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018-11-20 18:00:00', 1),
(12, 'Prateek2', '8837842284', '3', '3', '2 Days & 1 Night', 'dev.prateek.asthana@gmail.com', 'Hno 8, Nr ITDR, NH72, Jhajra, Dehradun', '7', 'Group Domestic', 'Sample Hotel1', '2018-12-02', '2018-12-02', 'Sample Day1', 'Sample Day2', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '', 'Normal', '', '', 'AP', 'None', 'None', 'No', 'No', 'Sample1,Sample2,Sample3', 'Sample1,Sample2,Sample3', '2018-12-03', '', '', '', '', '', '', '17:17', '', '', '', '', '', 'Reminder Subject', '', '', 'Sample1,Sample2, Sample3', '2018-12-02 10:57:27', 0),
(13, 'Sudipta Das', '7688001438', 'Text', '5', '5 Days & 4 Nights', 'CATCHSUDIPTA@GMAIL.COM', '15/54 F Jheel Road', '125122', 'Costomized Domestic', 'Hotel 1', '2018-12-05', '2018-12-10', '*Visit the famous Mughal Gardens, Cheshma Shahi (Royal Spring), Nishat Bagh (Garden of Pleasure), Shalimar Bagh (Abode of Love), which the Mughals laid out in the 16th century along the banks of Dal Lake in the heart of Srinagar. Also visit Shankaracharya Temple located on a hillock and enjoy panoramic views of the entire city, along with the famous Dal Lake & River Jhelum. On the way, visit the handloom centre famous for production of Pashmina/Shahtoosh shawls and carpets famous all over the world. *Have a comfortable overnight stay at the hotel.\r\nVisit the famous Mughal Gardens, Cheshma Shahi (Royal Spring), Nishat Bagh (Garden of Pleasure), Shalimar Bagh (Abode of Love), which the Mughals laid out in the 16th century along the banks of Dal Lake in the heart of Srinagar. Also visit Shankaracharya Temple located on a hillock and enjoy panoramic views of the entire city, along with the famous Dal Lake & River Jhelum. On the way *visit the handloom centre famous for production of Pashmina/Shahtoosh shawls and carpets famous all over the world. Have a comfortable overnight stay at the hotel.', 'Visit the famous Mughal Gardens, Cheshma Shahi (Royal Spring), Nishat Bagh (Garden of Pleasure), Shalimar Bagh (Abode of Love), which the Mughals laid out in the 16th century along the banks of Dal Lake in the heart of Srinagar. Also visit Shankaracharya Temple located on a hillock and enjoy panoramic views of the entire city, along with the famous Dal Lake & River Jhelum. On the way, visit the handloom centre famous for production of Pashmina/Shahtoosh shawls and carpets famous all over the world. Have a comfortable overnight stay at the hotel.', 'Visit the famous Mughal Gardens, Cheshma Shahi (Royal Spring), Nishat Bagh (Garden of Pleasure), Shalimar Bagh (Abode of Love), which the Mughals laid out in the 16th century along the banks of Dal Lake in the heart of Srinagar. Also visit Shankaracharya Temple located on a hillock and enjoy panoramic views of the entire city, along with the famous Dal Lake & River Jhelum. On the way, visit the handloom centre famous for production of Pashmina/Shahtoosh shawls and carpets famous all over the world. Have a comfortable overnight stay at the hotel.', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '', 'Standered A/C Room', '', '', 'AP', 'NA', 'NA', 'NA', 'NA', 'Visit the famous Mughal Gardens, Visit the famous Mughal Gardens, Visit the famous Mughal Gardens, Visit the famous Mughal Gardens,Visit the famous Mughal Gardens,', 'Visit the famous Mughal Gardens, Visit the famous Mughal Gardens, Visit the famous Mughal Gardens, Visit the famous Mughal Gardens,Visit the famous Mughal Gardens,', '2018-12-02', '', '', '', '', '', '', '', '', '', '', '', '', 'TEst', '', '', 'Visit the famous Mughal Gardens, Visit the famous Mughal Gardens, Visit the famous Mughal Gardens, Visit the famous Mughal Gardens,Visit the famous Mughal Gardens,', '2018-12-02 13:22:15', 0),
(14, 'Prateek Dev2', '8837842284', 'Sample Tour', '3', '4 Days & 3 Nights', 'dev.prateek.asthana@gmail.com', 'Hno8, nr idtr, jhajra', '8', 'Costomized Domestic', 'Ramada', '2018-12-04', '2018-12-05', '*Plan1*Plan2*Plan3*Plan4*Plan5', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '', 'Luxary', '', '', 'MAP', 'Sedan', 'UK07BX2917', 'No', 'No', 'Inc1, Inc2', 'Exc1, Exc2', '2018-12-04', '', '', '', '', '', '', '16:16', '', '', '', '', '', 'Final Test', '', '', 'TnC1, Tnc2, Tnc3, Tnc4', '2018-12-03 10:46:28', 0),
(15, 'Sudipta Das', '7688001438', 'Goa 4 Nights & 5 Days', '5', '5 Days & 4 Nights', 'CATCHSUDIPTA@GMAIL.COM', '15/54 F Jheel Road', '123545', 'Group Domestic', 'xyz', '2018-12-14', '2018-12-20', '*Spend your holiday at the party hub of India - Goa! On this day, you will take a flight from your departure city and arrive in Goa. Once you have checked-in, spend the day at leisure. Later, return to your hotel for a comfortable stay.*Spend your holiday at the party hub of India - Goa! On this day, you will take a flight from your departure city and arrive in Goa. Once you have checked-in, spend the day at leisure. Later, return to your hotel for a comfortable stay.*Spend your holiday at the party hub of India - Goa! On this day, you will take a flight from your departure city and arrive in Goa. Once you have checked-in, spend the day at leisure. Later, return to your hotel for a comfortable stay.*Spend your holiday at the party hub of India - Goa! On this day, you will take a flight from your departure city and arrive in Goa. Once you have checked-in, spend the day at leisure. Later, return to your hotel for a comfortable stay.*Spend your holiday at the party hub of India - Goa! On this day, you will take a flight from your departure city and arrive in Goa. Once you have checked-in, spend the day at leisure. Later, return to your hotel for a comfortable stay.', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '', 'xyz', '', '', 'AP', 'NA', 'NA', 'NA', 'NA', 'Spend your holiday at the party hub of India, Spend your holiday at the party hub of India, Spend your holiday at the party hub of India, Spend your holiday at the party hub of India ', 'Spend your holiday at the party hub of India, Spend your holiday at the party hub of India, Spend your holiday at the party hub of India, Spend your holiday at the party hub of India ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Spend your holiday at the party hub of India, Spend your holiday at the party hub of India, Spend your holiday at the party hub of India, Spend your holiday at the party hub of India ', '2018-12-04 05:37:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_id` int(11) NOT NULL,
  `agency_address` text NOT NULL,
  `bill_to` text NOT NULL,
  `ship_to` text NOT NULL,
  `bill_to_name` text NOT NULL,
  `ship_to_name` text NOT NULL,
  `bill_to_no` varchar(14) NOT NULL,
  `ship_to_no` varchar(14) NOT NULL,
  `customer_gst_no` text NOT NULL,
  `product_service1` text NOT NULL,
  `qty1` int(8) NOT NULL,
  `unit_price1` float NOT NULL,
  `cgst1` float NOT NULL,
  `sgst1` float NOT NULL,
  `igst1` float NOT NULL,
  `amount1` float NOT NULL,
  `product_service2` text NOT NULL,
  `qty2` int(8) NOT NULL,
  `unit_price2` float NOT NULL,
  `cgst2` float NOT NULL,
  `sgst2` float NOT NULL,
  `igst2` float NOT NULL,
  `amount2` float NOT NULL,
  `product_service3` text NOT NULL,
  `qty3` int(8) NOT NULL,
  `unit_price3` float NOT NULL,
  `cgst3` float NOT NULL,
  `sgst3` float NOT NULL,
  `igst3` float NOT NULL,
  `amount3` float NOT NULL,
  `amt_received` float NOT NULL,
  `due_date` date NOT NULL,
  `createddate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_id`, `agency_address`, `bill_to`, `ship_to`, `bill_to_name`, `ship_to_name`, `bill_to_no`, `ship_to_no`, `customer_gst_no`, `product_service1`, `qty1`, `unit_price1`, `cgst1`, `sgst1`, `igst1`, `amount1`, `product_service2`, `qty2`, `unit_price2`, `cgst2`, `sgst2`, `igst2`, `amount2`, `product_service3`, `qty3`, `unit_price3`, `cgst3`, `sgst3`, `igst3`, `amount3`, `amt_received`, `due_date`, `createddate`) VALUES
(5, '51, CENTRAL ROAD, Jadavpur, Kolkata, West Bengal (WB - 19), PIN Code 700032, India\r\n9831310522\r\nHOLIDAYLINK05@GMAIL.COM\r\nWWW.HOLIDAYLINK.CO.IN\r\nGSTIN: 19AXNPS7452G1ZS', 'VIVO COMMUNICATION DEVICE PVT. LTD\r\nMERLIN INFINITE, ROOM NO: 805 DN-51 SECTOR-V , SALT LAKE Kolkata, West Bengal (WB - 19), PIN Code 700091, India\r\nGSTIN: 19AAECV8793L1ZB', 'VIVO COMMUNICATION DEVICE PVT. LTD\r\nMERLIN INFINITE, ROOM NO: 805 DN-51 SECTOR-V , SALT LAKE Kolkata, West Bengal (WB - 19), PIN Code 700091, India\r\nVIVO COMMUNICATION DEVICE PVT. LTD', '', '', '', '', '', 'COORG TOUR PROGRAM 3 NIGHTS / 4DAYS MEAL PLAN : MAP PICK UP & DROP : BENGALURU AIRPORT INCLUSIONS : CAR, 1 DAYS SIGHT SEEING, FOODING & LODGING. SAC: 00440063', 2, 15, 761.9, 761.9, 0, 1553.8, '', 2, 15, 761.9, 761.9, 0, 1553.8, '', 2, 15, 761.9, 761.9, 0, 1553.8, 0, '0000-00-00', '2018-11-17'),
(6, '51, CENTRAL ROAD, Jadavpur, Kolkata, West Bengal (WB - 19), PIN Code 700032, India\r\n9831310522\r\nHOLIDAYLINK05@GMAIL.COM\r\nWWW.HOLIDAYLINK.CO.IN\r\nGSTIN: 19AXNPS7452G1ZS', 'VIVO COMMUNICATION DEVICE PVT. LTD\r\nMERLIN INFINITE, ROOM NO: 805 DN-51 SECTOR-V , SALT LAKE Kolkata, West Bengal (WB - 19), PIN Code 700091, India\r\nGSTIN: 19AAECV8793L1ZB', 'VIVO COMMUNICATION DEVICE PVT. LTD\r\nMERLIN INFINITE, ROOM NO: 805 DN-51 SECTOR-V , SALT LAKE Kolkata, West Bengal (WB - 19), PIN Code 700091, India\r\nVIVO COMMUNICATION DEVICE PVT. LTD', '', '', '', '', '', 'COORG TOUR PROGRAM (CHILD BELOW 10 YEARS) 3 NIGHTS / 4DAYS MEAL PLAN : MAP PICK UP & DROP : BENGALURU AIRPORT INCLUSIONS : CAR, 1 DAYS SIGHT SEEING, FOODING & LODGING. SAC: 00440063', 2, 15, 761.9, 761.9, 0, 1553.8, '', 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, '0000-00-00', '2018-11-17'),
(7, '51, CENTRAL ROAD, Jadavpur, Kolkata, West Bengal (WB - 19), PIN Code 700032, India\r\n9831310522\r\nHOLIDAYLINK05@GMAIL.COM\r\nWWW.HOLIDAYLINK.CO.IN\r\nGSTIN: 19AXNPS7452G1ZS', 'VIVO COMMUNICATION DEVICE PVT. LTD\r\nMERLIN INFINITE, ROOM NO: 805 DN-51 SECTOR-V , SALT LAKE Kolkata, West Bengal (WB - 19), PIN Code 700091, India\r\nGSTIN: 19AAECV8793L1ZB', 'VIVO COMMUNICATION DEVICE PVT. LTD\r\nMERLIN INFINITE, ROOM NO: 805 DN-51 SECTOR-V , SALT LAKE Kolkata, West Bengal (WB - 19), PIN Code 700091, India\r\nVIVO COMMUNICATION DEVICE PVT. LTD', '', '', '', '', '', '	COORG TOUR PROGRAM (CHILD BELOW 10 YEARS) 3 NIGHTS / 4DAYS MEAL PLAN : MAP PICK UP & DROP : BENGALURU AIRPORT INCLUSIONS : CAR, 1 DAYS SIGHT SEEING, FOODING & LODGING. SAC: 00440063', 1, 152380, 761.9, 761.9, 0, 153904, '', 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, '0000-00-00', '2018-11-17'),
(9, '', 'Sudipta Das\r\n15/54 F Jheel Road Kolkata 700075\r\n768800148\r\ncatchsudipta@gmail.com', 'Sudipta Das\r\n15/54 F Jheel Road Kolkata 700075\r\n768800148\r\ncatchsudipta@gmail.com', '', '', '', '', 'N/A', 'HOTEL BOOKING\r\nSudipta Das\r\n15/54 F Jheel Road Kolkata 700075\r\n768800148\r\ncatchsudipta@gmail.com', 5, 1500, 0, 0, 0, 7500, '', 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, '0000-00-00', '2018-11-18'),
(10, '', 'Sudipta Das\r\n15/54 F Jheel Road Kolkata 700075\r\n768800148\r\ncatchsudipta@gmail.com', 'Sudipta Das\r\n15/54 F Jheel Road Kolkata 700075\r\n768800148\r\ncatchsudipta@gmail.com', '', '', '', '', 'N/A', 'Sudipta Das\r\n15/54 F Jheel Road Kolkata 700075\r\n768800148\r\ncatchsudipta@gmail.com', 5, 1500, 0, 0, 0, 7500, '', 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, '0000-00-00', '2018-11-18'),
(11, '', 'Sudipta Das\r\n15/54 F Jheel Road Kolkata 700075\r\n768800148\r\ncatchsudipta@gmail.com', 'Sudipta Das\r\n15/54 F Jheel Road Kolkata 700075\r\n768800148\r\ncatchsudipta@gmail.com', '', '', '', '', '1111111', 'Sudipta Das\r\n15/54 F Jheel Road Kolkata 700075\r\n768800148\r\ncatchsudipta@gmail.com', 5, 1500, 0, 0, 0, 7500, '', 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 5000, '0000-00-00', '2018-11-18');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(8) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `createddate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `name`, `email`, `createddate`) VALUES
(1, 'admin', '5bc7a057e1fbd58f12bbd3f6329f57f9', 'Administrator', 'info@hachiweb.com', '2018-11-12 09:44:53'),
(2, 'dev', 'df52b626ef6ec226f7a0850dbc13ae75', 'Prateek2', 'dev.prateek.asthana@gmail.com', '2018-11-18 04:15:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking_form`
--
ALTER TABLE `booking_form`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_form`
--
ALTER TABLE `booking_form`
  MODIFY `booking_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
