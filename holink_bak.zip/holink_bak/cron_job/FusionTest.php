<?php
session_start();
$_SESSION['logged_in'] = true; //set you've logged in
$_SESSION['last_activity'] = time(); //your last activity was now, having logged in.
$_SESSION['expire_time'] = 3*60*60; 
// use SilverStripe\Control\Controller;
// use SilverStripe\Control\HTTPRequest;
// use SilverStripe\View\ArrayData;
// use SilverStripe\Forms\Form;
// use SilverStripe\Forms\FieldList;
// use SilverStripe\Forms\TextField;
// use SilverStripe\Forms\NumericField;
// use SilverStripe\Forms\CheckboxField;
// use SilverStripe\Forms\EmailField;
// use SilverStripe\Forms\TextareaField;
// use SilverStripe\Forms\FormAction;
// use SilverStripe\Forms\RequiredFields;
// use SilverStripe\CMS\Controllers\ContentController;
// use SilverStripe\SiteConfig\SiteConfig;
// use SilverStripe\Control\Email\Email;
// use SilverStripe\Security\PermissionProvider;
// use SilverStripe\Security\Permission;
// use SilverStripe\ORM\DataObject;
require('fpdf.php');

class FusionTestPage extends Page
{
//Set relationship
	private static $has_many = array(
		'FusionFormSubmissions' => 'FusionFormSubmission'
	);


}

class FusionTest_Controller extends ContentController
{
	private static $allowed_actions = array('ContactForm','someaction','doContactForm',);

	public function index(){
		$arrayData = new ArrayData([
			'FusionForm' => $this->ContactForm()
		]);
		
		echo $arrayData->renderWith('FusionTest');
	}	
	

	// public function getValue() {
	// 	$value = Session::get($this->getName());
	
	// 	// only regenerate if the token isn't already set in the session
	// 	if(!$value) {
	// 		$value = $this->generate();
	// 		$this->setValue($value);
	// 	}
	
	// 	return $value;
	// }
	
	//Create Contact Form
	public function ContactForm()
	{

		//Add form fields
		$fields = new FieldList(
			$Name = new TextField('Name','Customer*'),
			$Project = new TextField('Project','Project*'),
			$Welder = new TextField('Welder','Welder ID*'),
			$Description = new DropdownField('Description', 'Pipe Description*', array('DN (Nominal outside diameter)'=>'DN (Nominal outside diameter)','65'=>'65','75'=>'75','90'=>'90','110'=>'110','125'=>'125','140'=>'140','160'=>'160','180'=>'180','200'=>'200','225'=>'225','250'=>'250','280'=>'280','315'=>'315','355'=>'355','400'=>'400','450'=>'450','500'=>'500','560'=>'560','630'=>'630','710'=>'710',
			'800'=>'800','900'=>'900','1000'=>'1000','1200'=>'1200','1400'=>'1400','1600'=>'1600')),
			$Description2 = new DropdownField('Description2', '', array('PN For PE 100'=>'PN For PE 100','4'=>'4','5'=>'5','8'=>'8','10'=>'10','12.5'=>'12.5','16'=>'16','20'=>'20','25'=>'25')),
			$PipeBatchNo = new NumericField('PipeBatchNo','Pipe Batch No*'),
			$FusionDate = new TextField('FusionDate','Fusion Date*'),
			$FusionProcedure = new TextField('FusionProcedure','Fusion Procedure*'),
			$Contact = new NumericField('Contact','Contact Phone*'),
			$Email = new EmailField('Email','Email*'),
			// new LabelField('#Instruct','The information above is required in order to fulfil the reporting requirements of ISO 13954 '),
			// new LabelField('Mandatory fields'),
			//LiteralField::create('alert','<span id="alert"  style="padding:2px;width:100%;"></span>'),
			HeaderField::create('instruct','The information above is required in order to fulfil the reporting requirements of ISO 13954'),
			HeaderField::create('instruct2','Mandatory fields *'),
			LiteralField::create('report', '<a id="report" href="http://asmusswater.co.nz/SampleButtWeldTensileTestReport.pdf">CLICK HERE FOR SAMPLE REPORT</a>')
			
		);
		//Adding Placeholders
		$FusionDate->setAttribute('placeholder', 'Date of weld');
		$Name->setAttribute('placeholder', 'Clients name to be printed on the test report');
		$Project->setAttribute('placeholder', 'The job which the samples are being tested for');
		$Welder->setAttribute('placeholder', 'The name or unique weld number of the person who welded the sample');
		//$Description->setAttribute('placeholder', 'Diameter & SDR');
		$PipeBatchNo->setAttribute('placeholder', 'Batch number printed on pipe');
		$FusionProcedure->setAttribute('placeholder', 'The method used by the welder, eg. POP-003, ISO21307, LeHunt Polytech');
		
		
		$actions = new FieldList(
			FormAction::create('doContactForm', ' Submit ')
			//$formAction = new FormAction('doContactForm', ' Submit ')
		);
		
		
		//Create Form Validation required fields
		//RequiredFields::create('Customer*');
		$validator = new RequiredFields(['Name', 'Project','Welder', 
		'Description','Description2','PipeBatchNo', 'FusionDate','FusionProcedure','Contact', 'Email']);

		//Return form as an Object
		return new Form($this, 'ContactForm', $fields, $actions, $validator);
		 
		
	}

	
	//Process the contact form
	public function doContactForm($data, $form)
	{	$form->disableSecurityToken();
		//Create submission object
		$submission = new FusionFormSubmission();
		//save submission object into form object this function is needed so the submission values will be available from the $submission object.
		$form->saveInto($submission);
		$submission->write();
		$form->disableSecurityToken();
		
		
		//Email form submission to user.
		$from = 'testing@asmusswater.co.nz';

		//Get SiteConfig to get the email setting to send an email to them.
        //$config = SiteConfig::current_site_config();
        //$to = $config->ContactFormEmailAddress;
		$to = 'testing@asmusswater.co.nz';

		$from_time = strtotime("2000-01-01 00:00:00");
		$to_time = strtotime(date("Y/m/d h:i:sa"));
		$subject = ($to_time - $from_time);  
		$subString = "Asmuss Water Fusion Test AW".$subject;
        //$subject = "Application id: AW".round(abs($to_time - $from_time),2);    

		$body = 'Customer: ' . $submission->Name.'<br />';
		$body .= 'Project: ' . $submission->Project. '<br />';
		$body .= 'Welder ID: ' . $submission->Welder. '<br />';
		$body .= 'Pipe Description: ' .'DN-'. $submission->Description.', '.'PN-'.$submission->Description2. '<br />';
		$body .= 'Pipe Batch No: ' . $submission->PipeBatchNo. '<br />';
		$body .= 'Fusion Date: ' . $submission->FusionDate . '<br />';
		$body .= 'Fusion Procedure: ' . $submission->FusionProcedure . '<br />';
		$body .= 'Contact Phone: ' . $submission->Contact . '<br />';
        $body .= 'Email: ' . $submission->Email . '<br />';
		
		$dest = 'Buttweld_'.$subject.'.pdf';
		$newDate = date("d-m-Y", strtotime($submission->FusionDate));
		$formTitle = "Butt weld Test Request\nas per ISO 13954";
		$pdf = new FPDF();
		$pdf->AddPage();
		$pdf->Image('AsmussLogo.png',138,9,-100);
		$pdf->SetFont('Arial','B',12.4);
		$pdf->Multicell(179,20,"",0,"C");
		$pdf->SetFont('Arial','B',15);
		$pdf->SetTextColor(0,149,218);
		$pdf->SetLineWidth(0.7);
		$pdf->Multicell(184,20,$formTitle,1,"C");
		$pdf->Multicell(175,10,"",0,"C");
		$y = $pdf->GetY();
		$pdf->SetFont('Arial','B',11);
		$pdf->SetTextColor(52,60,63);
		$pdf->SetLineWidth(0);
		$pdf->Multicell(74,12,'Customer: ',1,"L");
		$x = $pdf->GetX();
		$pdf->SetXY($x + 74, $y);
		$pdf->Multicell(110,12,$submission->Name,1,"L");
		$pdf->Multicell(74,12,'Email: ',1,"L");
		$x = $pdf->GetX();
		$pdf->SetXY($x + 74, $y+12);
		$pdf->Multicell(110,12,$submission->Email,1,"L");
		$pdf->Multicell(74,12,'Unique ID:',1,"L");
		$x = $pdf->GetX();
		$pdf->SetXY($x + 74, $y+24);
		$pdf->Multicell(110,12,'AW'.$subject,1,"L");
		$pdf->Multicell(74,12,'Project: ',1,"L");
		$x = $pdf->GetX();
		$pdf->SetXY($x + 74, $y+36);
		$pdf->Multicell(110,12,$submission->Project,1,"L");
		$pdf->Multicell(74,12,'Pipe Description: ',1,"L");
		$x = $pdf->GetX();
		$pdf->SetXY($x + 74, $y+48);
		$pdf->Multicell(110,12,'DN-'.$submission->Description.', '.'PN-'.$submission->Description2,1,"L");
		$pdf->Multicell(74,12,'Pipe Batch No: ' ,1,"L");
		$x = $pdf->GetX();
		$pdf->SetXY($x + 74, $y+60);
		$pdf->Multicell(110,12,$submission->PipeBatchNo,1,"L");
		$pdf->Multicell(74,12,'Welder ID: ',1,"L");
		$x = $pdf->GetX();
		$pdf->SetXY($x + 74, $y+72);
		$pdf->Multicell(110,12,$submission->Welder,1,"L");
		$pdf->Multicell(74,12,'Contact Phone:',1,"L");
		$x = $pdf->GetX();
		$pdf->SetXY($x + 74, $y+84);
		$pdf->Multicell(110,12,$submission->Contact,1,"L");
		$pdf->Multicell(74,12,'Fusion Date: ',1,"L");
		$x = $pdf->GetX();
		$pdf->SetXY($x + 74, $y+96);
		$pdf->Multicell(110,12, $newDate,1,"L");
		$pdf->Multicell(74,12,'Fusion Procedure: ',1,"L");
		$x = $pdf->GetX();
		$pdf->SetXY($x + 74, $y+108);
		$pdf->Multicell(110,12,$submission->FusionProcedure,1,"L");
		
        // // SENDING IT TO SilverStripe's public folder
		$pdf->Output('F', $dest);
		$base = __DIR__;
		$base = substr($base,0,31).'/framework/'.$dest;
		try{
		$email = new Email($from, $to, $subString, $body);
		$email->AttachFile($base,$dest);
		$email->SetCC($submission->Email);
		$email->send();
		//Thank you message
		$_SESSION['name'] = $submission->Name;
		$_SESSION['email'] = $submission->Email;
		$_SESSION['uniqueid'] = $subject;
		$_SESSION['id']='butt';
		}
		catch (Exception $e) {
			echo 'Message could not be sent. Mailer Error: ', $e;
		}

		
		//$message = "Thank you! Your form has been submitted. Your unique ID //.'AW'.$subject;
		//echo "<script type='text/javascript'>alert('$message');</script>";

		return $this->redirect('http://www.asmusswater.co.nz/thanks2.php');
		//echo $base;

		//Once finished processing form redirect back to contact page.
		//return $this->redirectBack();
		
		
		}
	
	  

}
if( $_SESSION['last_activity'] < time()-$_SESSION['expire_time'] ) { //have we expired?
    //redirect to logout.php
    header('Location: http://asmusswater.co.nz/fusion'); 
} else{ //if we haven't expired:
    $_SESSION['last_activity'] = time(); //this was the moment of last activity.
}

