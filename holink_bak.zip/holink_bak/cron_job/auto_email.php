<?php 
	
// $link = mysqli_connect("localhost","thetrips_dev","hK5234VmJdB","thetrips_booking_management");
// if(mysqli_connect_error())
// {
    // die("There is some error in connecting to database");
// }
// $today = date('y-m-d');
// $query = "SELECT * FROM `booking_form` WHERE `reminder_date1` = '$today' OR `reminder_date2` = '$today' OR `reminder_date3` = '$today'";
// $process_query = mysqli_query($link,$query);
//Email form submission to user.
		$from = 'admin@holidaylink.co.in';
		$email = 'dev.prateek.asthana@gmail.com';
		// $from_time = strtotime("2000-01-01 00:00:00");
		// $to_time = strtotime(date("Y/m/d h:i:sa"));
		// $subject = ($to_time - $from_time);  
		// $subject = "BOOKING REMINDER HOLIDAY LINK".$subject;
		$subject = 'Test';
	    $headers = "From:admin@holidaylink.co.in";
		$message ='hghjhjkjh';
		// $headers = 'From: webmaster@example.com' . "\r\n" .
    // 'Reply-To: webmaster@example.com' . "\r\n" .
    // 'X-Mailer: PHP/' . phpversion();
			//. "\r\n" ."CC: somebodyelse@example.com";

// if(!empty($process_query)){
    // while($project = mysqli_fetch_assoc($process_query)){
        // $recipient = $project['email'];
        // if($project['reminder_date1'] == $today){
        // $hotel = $project['hotel1'];
        // }
        // else if($project['reminder_date2'] == $today){
            // $hotel = $project['hotel2'];
        // }
        // else{
            // $hotel = $project['hotel3'];
        // }
        // $message = "Hi! ".$project['name'].". This is a reminder regarding your booking with Holiday Link on ".$project['createddate']." for hotel ".$hotel.". Thank you, Team Holiday Link";
        // //$message = urlencode($message);
       
    // }
// }
$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
$mail->Host = "smtp.gmail.com";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->Username = "dev.prateek.asthana@gmail.com";
$mail->Password = "pratik0001";
$mail->SetFrom("dev.prateek.asthana@gmail.com");
$mail->Subject = "Test";
$mail->Body = "hello";
$mail->AddAddress("dev.prateek.asthana@gmail.com");

 if(!$mail->Send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
 } else {
    echo "Message has been sent";
 }
	
	
?>