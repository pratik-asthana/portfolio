<?php 
$link = mysqli_connect("localhost","thetrips_dev","hK5234VmJdB","thetrips_booking_management");
if(mysqli_connect_error())
{
    die("There is some error in connecting to database");
}
$id = isset($_GET['id'])?$_GET['id']:'';
$today = date('y-m-d');
// $today = (string)$today;
$query = "SELECT * FROM `booking_form` WHERE `reminder_date1` = '$today' OR `reminder_date2` = '$today' OR `reminder_date3` = '$today'";
$process_query = mysqli_query($link,$query);
if(!empty($process_query)){
    while($project = mysqli_fetch_assoc($process_query)){
        $recipient = urlencode($project['mobile']);
        if(date('y-m-d', strtotime($project['reminder_date1'])) == $today){
        $message = $project['reminder_subject1'];
        $remdate1 = $project['reminder_date1'];
        $remdate1 = date("dmY", strtotime($remdate1)); 
        $remtime1 = $project['reminder_time1'];
        // $remtime1 = ((int)$project['reminder_time1'])%60;
        // $remtime1 = $remtime1.':00';
        // $remtime1 = date('H:i:s', strtotime($remdate1));
        $sch = $remdate1.$remtime1;
        }
        else if(date('y-m-d', strtotime($project['reminder_date2'])) == $today){
            $message = $project['reminder_subject2'];
             $remdate2 = $project['reminder_date2'];
            $remdate2 = date("dmY", strtotime($remdate2));
            $remtime2 = $project['reminder_time2'];
            // $remtime2 = date('G:i', strtotime($remdate2));
            $sch = $remdate2.$remtime2;
        }
        else{
            $message = $project['reminder_subject3'];
             $remdate3 = $project['reminder_date3'];
            $remdate3 = date("dmY", strtotime($remdate3));
            $remtime3 = $project['reminder_time3'];
            // $remtime3 = date('G:i', strtotime($remdate3));
            $sch = $remdate3.$remtime3;
        }

		// echo '<pre>';	
		// print_r($message);
		// exit();
        //$message = "Hi! ".$project['name'].". This is a reminder regarding your booking with Holiday Link on ".$project['createddate']." for hotel ".$hotel.". Thank you, Team Holiday Link";
        $message = urlencode($message);
        // $sch = urlencode($sch);
        $url = "http://198.15.103.106/API/pushsms.aspx?loginID=BSAHA&password=123456&mobile=".$recipient."&text=".$message."&senderid=HOLINK&route_id=1&Unicode=0&sch=".$sch;
        // echo "<pre>";
        // print_r($url);
        // exit(); 
		$response = file_get_contents($url);
        $decode = json_decode($response);
        $status = $decode->LoginStatus;
		$trans_id = $decode->Transaction_ID;
        $res = 'Status: '.$status.'. Transaction_ID: '.$trans_id."<br>";
        echo $res;
		// $flag = 0;
        // if($status == 'Success'){
        //     $flag = 1;
        // }
    }
}
?>