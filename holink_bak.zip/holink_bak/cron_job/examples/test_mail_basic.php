<html>
<head>
<title>PHPMailer - Mail() basic test</title>
</head>
<body>

<?php

require_once('../class.phpmailer.php');

$mail = new PHPMailer(); // defaults to using php "mail()"

// $body             = file_get_contents('contents.html');
// $body             = preg_replace("[\]",'',$body);
$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);
$mail->SMTPDebug = 1;
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
//$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
$mail->Host = "smtp.gmail.com";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->Username = "dev.prateek.asthana@gmail.com";
$mail->Password = "pratik0001";

$body = "Test Message";

$mail->AddReplyTo("dev.prateek.asthana@gmail.com","Dev Prateek");

$mail->SetFrom('info@hachiweb.com', 'Prateek Asthana');

$mail->AddReplyTo("noreply@hachiweb.com.com","Prateek Dev");

$address = "dev.prateek.asthana@gmail.com";
$mail->AddAddress($address);

$mail->Subject    = "PHPMailer Test Subject via mail(), basic";

// $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

$mail->MsgHTML($body);

// $mail->AddAttachment("images/phpmailer.gif");      // attachment
// $mail->AddAttachment("images/phpmailer_mini.gif"); // attachment

if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
}

?>

</body>
</html>
