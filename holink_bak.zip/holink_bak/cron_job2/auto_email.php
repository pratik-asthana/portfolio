<?php
 use PHPMailer\PHPMailer\PHPMailer;
 use PHPMailer\PHPMailer\SMTP;
 use PHPMailer\PHPMailer\Exception;
 require("PHPMailer-6.0.6/src/PHPMailer.php");
 require("PHPMailer-6.0.6/src/SMTP.php");
 require("PHPMailer-6.0.6/src/Exception.php");


	$mail = new PHPMailer(); // create a new object
	$mail->IsSMTP();
	$mail->SMTPDebug = 1;
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = 'ssl';
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 465; // or 587
	$mail->IsHTML(true);
	$mail->Username = "mygmailid";
	$mail->Password = "mygmailpwd";
	$mail->SetFrom("admin@holidaylink.co.in");
	$mail->Subject = "Test";
	$mail->Body = "hello";
	$mail->AddAddress("dev.prateek.asthana@gmail.com");

	 if(!$mail->Send()) {
	    echo "Mailer Error: " . $mail->ErrorInfo;
	 } else {
	    echo "Message has been sent";
	 }
	
	
?>